# Zikkit SW Kill Switch v1

## 🎯 מה זה עושה

מתקן את הבאג ב-Service Worker הישן ש**שובר את האתר לכל המשתמשים**.

### לפני (הבאג):
- כל משתמש שנכנס לאתר מקבל sw.js תקול
- ה-SW שובר fetch requests → "client is offline"
- המשתמש לא יכול להתחבר

### אחרי (Kill Switch):
- ה-SW החדש מנקה את עצמו אוטומטית
- כל משתמש קיים שייכנס לאתר - ה-SW יוסר מדפדפן שלו תוך 2 שניות
- משתמשים חדשים לא יקבלו SW בכלל

## 📦 קבצים

```
public/sw.js              — Kill Switch SW (455 → 1.6KB)
public/clear-sw.html      — דף עזרה ידני (חירום)
```

## 🚀 התקנה — 5 דקות

### 1. גיבוי

```cmd
cd C:\zikkit
copy public\sw.js backup-before-pro-pack\sw-old.js
```

### 2. חילוץ

```cmd
cd C:\zikkit
tar -xzf ZIKKIT-SW-KILLSWITCH.tar.gz
```

### 3. בדיקת build מקומית

```cmd
rmdir /S /Q .next
npm run build
```

אמור לראות `✓ Compiled successfully` (אין שינויים ב-TypeScript - רק קבצי public).

### 4. דחוף לVercel

```cmd
git add public/sw.js public/clear-sw.html
git commit -m "fix: SW kill switch - removes broken SW from all users"
git push
vercel --prod
```

⏱️ 3-5 דקות.

## ✅ אחרי deploy

### מה יקרה למשתמשים קיימים שכבר נכנסו לאתר:
1. כשייכנסו - הדפדפן יוריד את ה-SW החדש
2. ה-SW יבטל את עצמו + ינקה caches
3. הטאב יטען מחדש אוטומטית
4. **הם יוכלו להיכנס** ⭐

### מה יקרה למשתמשים חדשים:
1. נכנסים לאתר
2. ה-SW נרשם
3. **מבטל את עצמו מיד**
4. בעצם לא יש להם SW פעיל
5. הכל עובד מהר ובלי בעיות

### אם משתמש עדיין תקוע (נדיר):
תפנה אותו ל: `https://zikkit-jvc7.vercel.app/clear-sw.html`
זה דף שמנקה הכל ידנית - יבוצע אוטומטית תוך 5 שניות.

## 🔮 שלב הבא (לעתיד)

כשתחליט להחזיר Service Worker אמיתי (למשל ל-PWA / push notifications):
1. אל תחזיר את הקוד הישן שלך
2. השתמש ב-Workbox או PWA-next של Next.js
3. הם מטפלים בנפילות נכון

## 🔙 חזרה לאחור

```cmd
cd C:\zikkit
copy /Y backup-before-pro-pack\sw-old.js public\sw.js
del public\clear-sw.html
```

(לא מומלץ - הקוד הישן הוא הבאג שלמדנו!)
