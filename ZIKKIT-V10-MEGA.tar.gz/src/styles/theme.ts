'use client';

import { createTheme, type ThemeOptions } from '@mui/material/styles';

// ─── Color tokens — mapped from legacy CSS :root ───
const palette = {
  bg: '#07090b',
  surface1: '#0b0e12',
  surface2: '#0f1318',
  surface3: '#141920',
  surface4: '#1a2230',
  surface5: '#202a3a',

  glass: 'rgba(255,255,255,0.025)',
  glass2: 'rgba(255,255,255,0.05)',
  glass3: 'rgba(255,255,255,0.08)',

  border: 'rgba(255,255,255,0.055)',
  border2: 'rgba(255,255,255,0.09)',
  border3: 'rgba(255,255,255,0.14)',

  accent: '#00e5b0',
  accent2: '#00c49a',
  accent3: '#00a882',
  accentGlow: 'rgba(0,229,176,0.18)',
  accentDim: 'rgba(0,229,176,0.08)',
  accentMid: 'rgba(0,229,176,0.15)',

  blue: '#4f8fff',
  blueDim: 'rgba(79,143,255,0.1)',
  purple: '#a78bfa',
  purpleDim: 'rgba(167,139,250,0.1)',
  hot: '#ff4d6d',
  hotDim: 'rgba(255,77,109,0.1)',
  warm: '#f59e0b',
  warmDim: 'rgba(245,158,11,0.1)',
  green: '#22c55e',
  greenDim: 'rgba(34,197,94,0.1)',
  teal: '#06b6d4',
  tealDim: 'rgba(6,182,212,0.1)',

  text: '#e8f0f4',
  text2: '#a8bcc8',
  text3: '#5a7080',
  text4: '#2e4050',
};

const themeOptions: ThemeOptions = {
  palette: {
    mode: 'dark',
    primary: {
      main: palette.accent,
      light: palette.accent2,
      dark: palette.accent3,
      contrastText: '#000',
    },
    secondary: {
      main: palette.blue,
      contrastText: '#fff',
    },
    error: {
      main: palette.hot,
    },
    warning: {
      main: palette.warm,
    },
    success: {
      main: palette.green,
    },
    info: {
      main: palette.teal,
    },
    background: {
      default: palette.bg,
      paper: palette.surface1,
    },
    text: {
      primary: palette.text,
      secondary: palette.text2,
      disabled: palette.text3,
    },
    divider: palette.border,
  },

  typography: {
    fontFamily: "'Inter', system-ui, -apple-system, sans-serif",
    h1: {
      fontFamily: "'Syne', sans-serif",
      fontWeight: 800,
      letterSpacing: '-0.5px',
    },
    h2: {
      fontFamily: "'Syne', sans-serif",
      fontWeight: 800,
      letterSpacing: '-0.4px',
    },
    h3: {
      fontFamily: "'Syne', sans-serif",
      fontWeight: 700,
      letterSpacing: '-0.3px',
    },
    h4: {
      fontFamily: "'Syne', sans-serif",
      fontWeight: 700,
    },
    h5: {
      fontFamily: "'Syne', sans-serif",
      fontWeight: 700,
    },
    h6: {
      fontFamily: "'Syne', sans-serif",
      fontWeight: 700,
      fontSize: '0.875rem',
    },
    body1: {
      fontSize: '0.8125rem',  // 13px
      lineHeight: 1.5,
    },
    body2: {
      fontSize: '0.75rem',    // 12px
      lineHeight: 1.5,
    },
    caption: {
      fontSize: '0.625rem',   // 10px
      fontWeight: 700,
      textTransform: 'uppercase' as const,
      letterSpacing: '0.5px',
    },
    button: {
      fontWeight: 700,
      textTransform: 'none' as const,
      fontSize: '0.75rem',
    },
  },

  shape: {
    borderRadius: 10,
  },

  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          background: palette.bg,
          WebkitFontSmoothing: 'antialiased',
          MozOsxFontSmoothing: 'grayscale',
        },
        '::-webkit-scrollbar': {
          width: '3px',
          height: '3px',
        },
        '::-webkit-scrollbar-track': {
          background: 'transparent',
        },
        '::-webkit-scrollbar-thumb': {
          background: palette.border2,
          borderRadius: '99px',
        },
        '::-webkit-scrollbar-thumb:hover': {
          background: palette.accent3,
        },
      },
    },

    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          padding: '10px 18px',
          fontWeight: 700,
          fontSize: '0.75rem',
          letterSpacing: '0.1px',
          boxShadow: 'none',
          '&:hover': { boxShadow: 'none' },
        },
        containedPrimary: {
          background: `linear-gradient(135deg, ${palette.accent}, ${palette.accent2})`,
          color: '#000',
          '&:hover': {
            transform: 'translateY(-1px)',
            boxShadow: `0 8px 24px ${palette.accentGlow}`,
            filter: 'brightness(1.05)',
          },
        },
        outlined: {
          background: palette.glass2,
          color: palette.text2,
          borderColor: palette.border2,
          '&:hover': {
            borderColor: palette.border3,
            color: palette.text,
            background: palette.surface4,
          },
        },
      },
      defaultProps: {
        disableElevation: true,
      },
    },

    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            background: palette.surface3,
            borderRadius: 10,
            fontSize: '0.8125rem',
            '& fieldset': {
              borderColor: palette.border2,
            },
            '&:hover fieldset': {
              borderColor: palette.border3,
            },
            '&.Mui-focused fieldset': {
              borderColor: 'rgba(0,229,176,0.45)',
              boxShadow: `0 0 0 3px ${palette.accentDim}`,
            },
          },
          '& .MuiInputBase-input': {
            padding: '12px 14px',
            color: palette.text,
          },
          '& .MuiInputBase-input::placeholder': {
            color: palette.text4,
            opacity: 1,
          },
        },
      },
    },

    MuiSelect: {
      styleOverrides: {
        root: {
          background: palette.surface3,
          borderRadius: 10,
          fontSize: '0.8125rem',
        },
      },
    },

    MuiCard: {
      styleOverrides: {
        root: {
          background: palette.surface2,
          border: `1px solid ${palette.border}`,
          borderRadius: 14,
          transition: 'border-color 0.2s, box-shadow 0.2s',
          '&:hover': {
            borderColor: palette.border2,
            boxShadow: '0 8px 28px rgba(0,0,0,0.25)',
          },
        },
      },
    },

    MuiDialog: {
      styleOverrides: {
        paper: {
          background: palette.surface1,
          border: `1px solid ${palette.border2}`,
          borderRadius: 20,
          boxShadow: `0 0 0 1px ${palette.border}, 0 50px 120px rgba(0,0,0,0.65)`,
        },
      },
    },

    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 20,
          fontWeight: 700,
          fontSize: '0.625rem',
          letterSpacing: '0.2px',
        },
      },
    },

    MuiTableHead: {
      styleOverrides: {
        root: {
          '& th': {
            fontSize: '0.625rem',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.5px',
            color: palette.text3,
            borderBottom: `1px solid ${palette.border}`,
            background: palette.surface1,
            padding: '9px 12px',
          },
        },
      },
    },

    MuiTableBody: {
      styleOverrides: {
        root: {
          '& td': {
            padding: '11px 12px',
            borderBottom: `1px solid ${palette.border}`,
            fontSize: '0.75rem',
          },
          '& tr:last-child td': {
            borderBottom: 'none',
          },
          '& tr:hover td': {
            background: palette.glass,
            cursor: 'pointer',
          },
        },
      },
    },

    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          background: palette.surface4,
          border: `1px solid ${palette.border3}`,
          fontSize: '0.6875rem',
          fontWeight: 600,
          borderRadius: 8,
          boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
        },
      },
    },
  },
};

export const theme = createTheme(themeOptions);

// Export raw palette for use outside MUI components
export { palette as zikkitColors };
