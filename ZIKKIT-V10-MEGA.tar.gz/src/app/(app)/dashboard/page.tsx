'use client';

import { useL } from '@/hooks/useL';
import { useLanguage } from '@/hooks/useLanguage';
import { useMemo } from 'react';
import { Box, Typography, Button } from '@mui/material';
import { useRouter } from 'next/navigation';
import { Badge } from '@/components/ui/Badge';
import { useAuth } from '@/features/auth/AuthProvider';
import { useData } from '@/hooks/useFirestore';
import { zikkitColors as c } from '@/styles/theme';
import { formatCurrency } from '@/lib/formatters';
import { JOB_STATUS_CONFIG } from '@/lib/constants';
import type { Job } from '@/types';

// ── Helpers ──
function StatCard({ value, label, trend, color = c.accent }: { value: string; label: string; trend?: string; color?: string }) {
  const isUp = trend?.startsWith('+') || trend?.startsWith('↑');
  return (
    <Box sx={{ p: '16px 18px', borderRadius: '14px', bgcolor: c.surface2, border: `1px solid ${c.border}`, transition: '0.2s', '&:hover': { borderColor: `${color}40` } }}>
      <Typography sx={{ fontSize: 11, color: c.text3, fontWeight: 600, mb: '6px' }}>{label}</Typography>
      <Typography sx={{ fontSize: 24, fontWeight: 900, color, fontFamily: "'Syne', sans-serif" }}>{value}</Typography>
      {trend && <Typography sx={{ fontSize: 11, fontWeight: 700, color: isUp ? c.green : c.hot, mt: '4px' }}>{trend}</Typography>}
    </Box>
  );
}

function SectionTitle({ icon, title, count, action }: { icon: string; title: string; count?: number; action?: React.ReactNode }) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: '12px' }}>
      <Typography sx={{ fontSize: 14, fontWeight: 700, color: c.text, display: 'flex', alignItems: 'center', gap: '8px' }}>
        <span style={{ fontSize: 16 }}>{icon}</span> {title}
        {count != null && count > 0 && <Box component="span" sx={{ fontSize: 11, fontWeight: 700, color: c.accent, bgcolor: c.accentDim, px: '8px', py: '2px', borderRadius: '6px' }}>{count}</Box>}
      </Typography>
      {action}
    </Box>
  );
}

function AlertItem({ text, type, onClick }: { text: string; type: 'danger' | 'warning' | 'info'; onClick?: () => void }) {
  const colors = { danger: c.hot, warning: c.warm, info: c.blue };
  const color = colors[type];
  return (
    <Box onClick={onClick} sx={{ display: 'flex', alignItems: 'center', gap: '10px', p: '10px 14px', borderRadius: '10px', bgcolor: `${color}08`, border: `1px solid ${color}18`, cursor: onClick ? 'pointer' : 'default', transition: '0.15s', '&:hover': onClick ? { bgcolor: `${color}12` } : {}, mb: '6px' }}>
      <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: color, flexShrink: 0, animation: type === 'danger' ? 'pulse 2s infinite' : 'none' }} />
      <Typography sx={{ fontSize: 12, color: c.text2, flex: 1 }}>{text}</Typography>
      {onClick && <Typography sx={{ fontSize: 11, color, fontWeight: 700 }}>→</Typography>}
    </Box>
  );
}

function ScheduleItem({ time, client, type, address, status }: { time: string; client: string; type?: string; address?: string; status: string }) {
  const cfg = JOB_STATUS_CONFIG[status as keyof typeof JOB_STATUS_CONFIG];
  return (
    <Box sx={{ display: 'flex', gap: '12px', p: '10px 0', borderBottom: `1px solid ${c.border}`, '&:last-child': { borderBottom: 'none' } }}>
      <Box sx={{ width: 48, textAlign: 'center', flexShrink: 0 }}>
        <Typography sx={{ fontSize: 13, fontWeight: 700, color: c.text }}>{time}</Typography>
      </Box>
      <Box sx={{ flex: 1 }}>
        <Typography sx={{ fontSize: 13, fontWeight: 600, color: c.text }}>{client}</Typography>
        <Typography sx={{ fontSize: 11, color: c.text3 }}>{type}{address ? ` — ${address}` : ''}</Typography>
      </Box>
      {cfg && <Badge label={(lang==="he"?cfg.he:cfg.label)} variant={cfg.badge as 'b-open' | 'b-done' | 'b-hot' | 'b-warm' | 'b-grey' | 'b-new' | 'b-purple'} />}
    </Box>
  );
}

function TechRank({ rank, name, revenue, jobs }: { rank: number; name: string; revenue: number; jobs: number }) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: '10px', p: '8px 0', borderBottom: `1px solid ${c.border}`, '&:last-child': { borderBottom: 'none' } }}>
      <Box sx={{ width: 24, height: 24, borderRadius: '6px', bgcolor: rank === 1 ? c.accentDim : c.glass2, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 800, color: rank === 1 ? c.accent : c.text3 }}>{rank}</Box>
      <Typography sx={{ flex: 1, fontSize: 13, fontWeight: 600, color: c.text }}>{name}</Typography>
      <Box sx={{ textAlign: 'right' }}>
        <Typography sx={{ fontSize: 12, fontWeight: 700, color: c.green }}>{formatCurrency(revenue)}</Typography>
        <Typography sx={{ fontSize: 10, color: c.text3 }}>{jobs} jobs</Typography>
      </Box>
    </Box>
  );
}

// ── Main Dashboard ──
export default function DashboardPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { db, cfg } = useData();
  const L = useL();
  const { lang } = useLanguage();

  const today = new Date().toISOString().slice(0, 10);
  const now = Date.now();
  const dayMs = 24 * 60 * 60 * 1000;

  const allJobs = db.jobs || [];
  const allLeads = db.leads || [];
  const techs = useMemo(() => (db.users || []).filter((u) => u.role === 'tech' || u.role === 'technician'), [db.users]);

  // Today schedule
  const todayJobs = useMemo(() =>
    allJobs.filter((j) => {
      const d = j.scheduledDate || j.date || j.created || '';
      return d.startsWith(today) && !['completed', 'cancelled'].includes(j.status);
    }).slice(0, 6),
  [allJobs, today]);

  // Revenue 7 days
  const revenueByDay = useMemo(() => {
    const days: { label: string; revenue: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now - i * dayMs);
      const key = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString('en-US', { weekday: 'short' });
      const rev = allJobs.filter((j) => j.status === 'completed' && (j.created || '').startsWith(key)).reduce((s, j) => s + (j.revenue || 0), 0);
      days.push({ label, revenue: rev });
    }
    return days;
  }, [allJobs, now, dayMs]);

  const weekRevenue = revenueByDay.reduce((s, d) => s + d.revenue, 0);
  const maxDayRevenue = revenueByDay.length > 0 ? Math.max(...revenueByDay.map((d) => d.revenue), 1) : 1;

  // Month revenue
  const monthRevenue = useMemo(() => {
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0);
    return allJobs.filter(j => j.status === 'completed' && new Date(j.created || 0) >= monthStart).reduce((s, j) => s + (j.revenue || 0), 0);
  }, [allJobs]);

  // Open jobs count
  const openJobs = allJobs.filter(j => !['completed', 'cancelled'].includes(j.status)).length;
  const newLeads = allLeads.filter(l => l.status === 'new' || l.status === 'hot').length;
  const botCalls = (db.botLog || []).length;

  // Needs attention alerts
  const unassigned = allJobs.filter(j => !j.tech && !['completed', 'cancelled'].includes(j.status));
  const unansweredLeads = allLeads.filter(l => l.status === 'new');
  const overdueJobs = allJobs.filter(j => {
    if (['completed', 'cancelled'].includes(j.status)) return false;
    return (now - new Date(j.created || 0).getTime()) > 2 * dayMs;
  });

  // Top techs this month
  const topTechs = useMemo(() => {
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0);
    const counts: Record<string, { name: string; jobs: number; revenue: number }> = {};
    allJobs.forEach(j => {
      if (j.status === 'completed' && j.tech && new Date(j.created || 0) >= monthStart) {
        if (!counts[j.tech]) counts[j.tech] = { name: j.tech, jobs: 0, revenue: 0 };
        counts[j.tech].jobs++;
        counts[j.tech].revenue += j.revenue || 0;
      }
    });
    return Object.values(counts).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  }, [allJobs]);

  // Greeting
  const [now] = useState(() => new Date());
  const hour = now.getHours();
  const greeting = hour < 12 ? L('Good morning','בוקר טוב') : hour < 17 ? L('Good afternoon','צהריים טובים') : L('Good evening','ערב טוב');
  const dateStr = now.toLocaleDateString('he-IL', { weekday: 'long', month: 'long', day: 'numeric' });

  const needsAttention = unassigned.length + unansweredLeads.length + overdueJobs.length;

  return (
    <Box sx={{ className: 'zk-fade-up', pb: '80px' }}>
      {/* ── Greeting ── */}
      <Box sx={{ mb: '20px' }}>
        <Typography sx={{ fontSize: { xs: 20, md: 24 }, fontWeight: 900, fontFamily: "'Syne', sans-serif", color: c.text }}>
          {greeting}, {user?.name?.split(' ')[0] || 'בוס'}
        </Typography>
        <Typography sx={{ fontSize: 13, color: c.text3, mt: '2px' }}>{dateStr}</Typography>
      </Box>

      {/* ── KPI Cards ── */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(4, 1fr)' }, gap: { xs: '8px', md: '12px' }, mb: '20px' }}>
        <StatCard value={formatCurrency(monthRevenue)} label={L("Monthly Revenue","הכנסות החודש")} color={c.accent} />
        <StatCard value={String(openJobs)} label={L("Open Jobs","עבודות פתוחות")} color={c.blue} />
        <StatCard value={String(newLeads)} label={L("ליד חדשs","לידים חדשים")} color={c.warm} />
        <StatCard value={String(botCalls)} label={L("Bot Calls","שיחות בוט")} trend={botCalls > 0 ? `${Math.round((botCalls - (db.botLog || []).filter(l => l.msg?.includes('Missed')).length) / Math.max(botCalls, 1) * 100)}% answered` : undefined} color={c.purple} />
      </Box>

      {/* ── Main Grid ── */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: '14px', mb: '20px' }}>

        {/* Revenue Chart */}
        <Box sx={{ bgcolor: c.surface2, borderRadius: '14px', border: `1px solid ${c.border}`, p: '16px 18px' }}>
          <SectionTitle icon="📊" title={L("Weekly Revenue","הכנסות שבועיות")} action={<Typography sx={{ fontSize: 13, fontWeight: 800, color: c.green }}>{formatCurrency(weekRevenue)}</Typography>} />
          <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: '6px', height: 120, mt: '8px' }}>
            {revenueByDay.map((d, i) => (
              <Box key={i} sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                <Box sx={{ width: '100%', bgcolor: c.accentDim, borderRadius: '6px 6px 0 0', minHeight: 4, height: `${(d.revenue / maxDayRevenue) * 100}%`, transition: 'height 0.5s ease', '&:hover': { bgcolor: c.accent } }} />
                <Typography sx={{ fontSize: 10, color: c.text3 }}>{d.label}</Typography>
              </Box>
            ))}
          </Box>
          {/* Revenue Goal */}
          {(() => {
            const goal = (cfg as Record<string, unknown>).monthlyGoal as number || 0;
            if (goal <= 0) return null;
            const pct = Math.min((monthRevenue / goal) * 100, 100);
            return (
              <Box sx={{ mt: '14px', pt: '12px', borderTop: `1px solid ${c.border}` }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: '6px' }}>
                  <Typography sx={{ fontSize: 11, fontWeight: 600, color: c.text3 }}>{L("Monthly Goal","יעד חודשי")}</Typography>
                  <Typography sx={{ fontSize: 11, fontWeight: 700, color: pct >= 100 ? c.green : c.text2 }}>{Math.round(pct)}%</Typography>
                </Box>
                <Box sx={{ height: 6, bgcolor: c.glass2, borderRadius: 3 }}>
                  <Box sx={{ height: '100%', width: `${pct}%`, bgcolor: pct >= 100 ? c.green : c.accent, borderRadius: 3, transition: 'width 0.8s ease' }} />
                </Box>
              </Box>
            );
          })()}
        </Box>

        {/* Needs Attention */}
        <Box sx={{ bgcolor: c.surface2, borderRadius: '14px', border: `1px solid ${c.border}`, p: '16px 18px' }}>
          <SectionTitle icon="🔥" title={L("Needs Attention","דורש טיפול")} count={needsAttention} />
          {needsAttention === 0 ? (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography sx={{ fontSize: 28, mb: 1 }}>✅</Typography>
              <Typography sx={{ fontSize: 13, color: c.text3 }}>All caught up! Nothing needs attention.</Typography>
            </Box>
          ) : (
            <>
              {unassigned.length > 0 && <AlertItem text={`${unassigned.length} job${unassigned.length > 1 ? 's' : ''} without a technician`} type="danger" onClick={() => router.push('/jobs')} />}
              {unansweredLeads.length > 0 && <AlertItem text={`${unansweredLeads.length} new lead${unansweredLeads.length > 1 ? 's' : ''} waiting for response`} type="warning" onClick={() => router.push('/leads')} />}
              {overdueJobs.length > 0 && <AlertItem text={`${overdueJobs.length} overdue job${overdueJobs.length > 1 ? 's' : ''} (open > 48h)`} type="info" onClick={() => router.push('/jobs')} />}
            </>
          )}
        </Box>
      </Box>

      {/* ── Bottom Grid ── */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: '14px', mb: '20px' }}>

        {/* Today's Schedule */}
        <Box sx={{ bgcolor: c.surface2, borderRadius: '14px', border: `1px solid ${c.border}`, p: '16px 18px' }}>
          <SectionTitle icon="📅" title={L("Today's Schedule","לוח זמנים היום")} count={todayJobs.length} action={
            <Button size="small" onClick={() => router.push('/jobs')} sx={{ fontSize: 11, color: c.accent, textTransform: 'none', fontWeight: 600, p: '2px 8px' }}>{L('View all','הצג הכל')}</Button>
          } />
          {todayJobs.length === 0 ? (
            <Box sx={{ textAlign: 'center', py: 3 }}>
              <Typography sx={{ fontSize: 24, mb: 1 }}>📭</Typography>
              <Typography sx={{ fontSize: 12, color: c.text3 }}>{L('No jobs scheduled for today','אין עבודות מתוכננות להיום')}</Typography>
            </Box>
          ) : (
            todayJobs.map((j) => (
              <ScheduleItem
                key={j.id}
                time={j.scheduledDate?.slice(11, 16) || '--:--'}
                client={j.client || 'Unknown'}
                type={j.type}
                address={j.address}
                status={j.status}
              />
            ))
          )}
        </Box>

        {/* Top Technicians */}
        <Box sx={{ bgcolor: c.surface2, borderRadius: '14px', border: `1px solid ${c.border}`, p: '16px 18px' }}>
          <SectionTitle icon="🏆" title={L("Top Technicians","טכנאים מובילים")} action={
            <Button size="small" onClick={() => router.push('/technicians')} sx={{ fontSize: 11, color: c.accent, textTransform: 'none', fontWeight: 600, p: '2px 8px' }}>{L('View all','הצג הכל')}</Button>
          } />
          {topTechs.length === 0 ? (
            <Box sx={{ textAlign: 'center', py: 3 }}>
              <Typography sx={{ fontSize: 24, mb: 1 }}>👷</Typography>
              <Typography sx={{ fontSize: 12, color: c.text3 }}>{L('No completed jobs this month yet','אין עבודות שהושלמו החודש')}</Typography>
            </Box>
          ) : (
            topTechs.map((t, i) => <TechRank key={t.name} rank={i + 1} name={t.name} revenue={t.revenue} jobs={t.jobs} />)
          )}
        </Box>
      </Box>

      {/* ── Quick Actions ── */}
      <Box sx={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        {[
          { label: L('+ עבודה חדשה','+ עבודה חדשה'), href: '/jobs', color: c.accent },
          { label: L('+ ליד חדש','+ ליד חדש'), href: '/leads', color: c.blue },
          { label: L('+ הצעת מחיר חדשה','+ הצעת מחיר'), href: '/quotes', color: c.purple },
        ].map((a) => (
          <Button
            key={a.label}
            onClick={() => router.push(a.href)}
            sx={{
              bgcolor: `${a.color}12`,
              color: a.color,
              fontWeight: 700,
              fontSize: 12,
              px: 2.5,
              py: 1,
              borderRadius: '10px',
              textTransform: 'none',
              border: `1px solid ${a.color}25`,
              '&:hover': { bgcolor: `${a.color}20` },
            }}
          >
            {a.label}
          </Button>
        ))}
      </Box>
    </Box>
  );
}
