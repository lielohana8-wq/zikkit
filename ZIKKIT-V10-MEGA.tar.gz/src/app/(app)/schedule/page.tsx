'use client';
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  Box, Typography, IconButton, Button, Chip, Avatar, Tooltip, Badge,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, Select, MenuItem,
  FormControl, InputLabel, Drawer, Divider, LinearProgress, Alert,
  ToggleButton, ToggleButtonGroup, Menu, Checkbox,
  Snackbar, Collapse, useMediaQuery, useTheme, Paper
} from '@mui/material';
import {
  ChevronLeft, ChevronRight, Today, ViewWeek, ViewDay, CalendarMonth,
  Add, Edit, Delete, Print, FilterList, AutoFixHigh,
  AccessTime, LocationOn, Person,
  Schedule as ScheduleIcon, ViewTimeline
} from '@mui/icons-material';
import { useData } from '@/hooks/useFirestore';
import { useL } from '@/hooks/useL';
import { useToast } from '@/hooks/useToast';
import { formatJobNumber } from '@/lib/formatters';
import type { Job, JobStatus } from '@/types/job';
import type { User } from '@/types/user';

const HOUR_HEIGHT = 60;
const MIN_SLOT_HEIGHT = 20;
const SIDEBAR_WIDTH = 280;
type ViewMode = 'day' | 'week' | 'month' | 'timeline';

const STATUS_COLORS: Record<string, { color: string; bg: string; he: string }> = {
  open: { color: '#FFB020', bg: '#FFF8E1', he: 'פתוח' },
  assigned: { color: '#3B82F6', bg: '#EBF5FF', he: 'שויך' },
  in_progress: { color: '#F97316', bg: '#FFF7ED', he: 'בטיפול' },
  waiting_parts: { color: '#8B5CF6', bg: '#F3E8FF', he: 'ממתין לחלקים' },
  parts_arrived: { color: '#06B6D4', bg: '#ECFEFF', he: 'חלקים הגיעו' },
  scheduled: { color: '#3B82F6', bg: '#EBF5FF', he: 'מתוכנן' },
  completed: { color: '#10B981', bg: '#ECFDF5', he: 'הושלם' },
  cancelled: { color: '#EF4444', bg: '#FEF2F2', he: 'בוטל' },
  no_answer: { color: '#94A3B8', bg: '#F1F5F9', he: 'אין מענה' },
  callback: { color: '#EC4899', bg: '#FDF2F8', he: 'חזרה' },
  dispute: { color: '#EF4444', bg: '#FEF2F2', he: 'מחלוקת' },
};
const TECH_COLORS = ['#3B82F6','#10B981','#F97316','#8B5CF6','#EF4444','#06B6D4','#EC4899','#84CC16','#F59E0B','#6366F1'];
const PRIORITY_CONFIG: Record<string, { he: string; color: string; icon: string }> = {
  low: { he: 'נמוך', color: '#94A3B8', icon: '▽' },
  normal: { he: 'רגיל', color: '#3B82F6', icon: '◇' },
  high: { he: 'גבוה', color: '#F97316', icon: '△' },
  urgent: { he: 'דחוף', color: '#EF4444', icon: '⬆' },
};
const HOURS = Array.from({ length: 15 }, (_, i) => i + 6);
const DAY_NAMES = ['ראשון','שני','שלישי','רביעי','חמישי','שישי','שבת'];

function fmtDate(d: Date): string { return d.toISOString().split('T')[0]; }
function isTodayStr(d: string) { return d === fmtDate(new Date()); }
function getWeekDates(date: Date): string[] {
  const d = new Date(date); d.setDate(d.getDate() - d.getDay());
  return Array.from({ length: 7 }, (_, i) => { const x = new Date(d); x.setDate(x.getDate() + i); return fmtDate(x); });
}
function getMonthDates(date: Date): string[] {
  const y = date.getFullYear(), m = date.getMonth();
  const first = new Date(y, m, 1), last = new Date(y, m + 1, 0);
  const dates: string[] = [];
  for (let i = first.getDay(); i > 0; i--) dates.push(fmtDate(new Date(y, m, 1 - i)));
  for (let i = 1; i <= last.getDate(); i++) dates.push(fmtDate(new Date(y, m, i)));
  const rem = 7 - (dates.length % 7); if (rem < 7) for (let i = 1; i <= rem; i++) dates.push(fmtDate(new Date(y, m + 1, i)));
  return dates;
}
function timeToY(time: string, hh = HOUR_HEIGHT) { const [h, m] = (time || '09:00').split(':').map(Number); return (h - 6) * hh + (m / 60) * hh; }
function yToTime(y: number, hh = HOUR_HEIGHT) { const total = Math.round((y / hh) * 60) + 360; const snapped = Math.round(total / 15) * 15; return `${String(Math.floor(snapped / 60)).padStart(2, '0')}:${String(snapped % 60).padStart(2, '0')}`; }
function getJobDate(j: Job) { return j.scheduledDate || j.date || j.created?.split('T')[0] || ''; }
function getJobTime(j: Job) { return j.scheduledTime || j.time || '09:00'; }
function getJobDuration() { return 60; }
function addMins(t: string, m: number) { const [h, mi] = t.split(':').map(Number); const total = h * 60 + mi + m; return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`; }
function getTechColor(i: number) { return TECH_COLORS[i % TECH_COLORS.length]; }

function detectConflicts(jobs: Job[], techName: string, date: string) {
  const tj = jobs.filter(j => j.tech === techName && getJobDate(j) === date && j.status !== 'cancelled').sort((a, b) => getJobTime(a).localeCompare(getJobTime(b)));
  const c: { a: Job; b: Job }[] = [];
  for (let i = 0; i < tj.length - 1; i++) { if (addMins(getJobTime(tj[i]), getJobDuration()) > getJobTime(tj[i + 1])) c.push({ a: tj[i], b: tj[i + 1] }); }
  return c;
}

function autoAssign(unassigned: Job[], techs: User[], allJobs: Job[]) {
  const assignments: { jobId: number; techName: string; techId: number | string }[] = [];
  const load: Record<string, number> = {}; techs.forEach(t => { load[t.name] = 0; });
  allJobs.forEach(j => { if (j.tech && load[j.tech] !== undefined) load[j.tech]++; });
  for (const job of unassigned) {
    let best: User | null = null, bestLoad = Infinity;
    for (const t of techs) { if ((load[t.name] || 0) < bestLoad) { bestLoad = load[t.name] || 0; best = t; } }
    if (best) { assignments.push({ jobId: job.id, techName: best.name, techId: best.id }); load[best.name] = (load[best.name] || 0) + 1; }
  }
  return assignments;
}

export default function SchedulePage() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { db, saveData } = useData();
  const { toast } = useToast();
  const [viewMode, setViewMode] = useState<ViewMode>('week');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedTechs, setSelectedTechs] = useState<string[]>([]);
  const [editJob, setEditJob] = useState<Job | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [createSlot, setCreateSlot] = useState<{ date: string; time: string; tech?: string } | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  const [filterAnchor, setFilterAnchor] = useState<null | HTMLElement>(null);
  const [dragJob, setDragJob] = useState<Job | null>(null);
  const [mounted, setMounted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => { setMounted(true); }, []);
  const allJobs = useMemo(() => db.jobs || [], [db.jobs]);
  const technicians = useMemo(() => (db.users || []).filter((u: User) => u.role === 'tech' || u.role === 'technician'), [db.users]);
  useEffect(() => { if (selectedTechs.length === 0 && technicians.length > 0) setSelectedTechs(technicians.map((t: User) => t.name)); }, [technicians]);
  const dateRange = useMemo(() => { if (viewMode === 'day') return [fmtDate(currentDate)]; if (viewMode === 'week' || viewMode === 'timeline') return getWeekDates(currentDate); return getMonthDates(currentDate); }, [viewMode, currentDate]);
  const unassignedJobs = useMemo(() => allJobs.filter((j: Job) => !j.tech && j.status !== 'completed' && j.status !== 'cancelled'), [allJobs]);
  const filteredJobs = useMemo(() => { const inRange = allJobs.filter((j: Job) => { const d = getJobDate(j); return d >= dateRange[0] && d <= dateRange[dateRange.length - 1]; }); if (selectedTechs.length === technicians.length) return inRange; return inRange.filter((j: Job) => j.tech && selectedTechs.includes(j.tech)); }, [allJobs, dateRange, selectedTechs, technicians]);
  const conflicts = useMemo(() => { const all: any[] = []; for (const tech of technicians) for (const date of dateRange) all.push(...detectConflicts(allJobs, tech.name, date)); return all; }, [allJobs, technicians, dateRange]);
  useEffect(() => { if (scrollRef.current && (viewMode === 'day' || viewMode === 'week')) { scrollRef.current.scrollTop = Math.max(0, timeToY(`${new Date().getHours()}:${new Date().getMinutes()}`) - 200); } }, [viewMode]);
  const navigate = (dir: number) => { const d = new Date(currentDate); if (viewMode === 'day') d.setDate(d.getDate() + dir); else if (viewMode === 'week' || viewMode === 'timeline') d.setDate(d.getDate() + 7 * dir); else d.setMonth(d.getMonth() + dir); setCurrentDate(d); };
  const updateJobInDb = useCallback(async (jobId: number, updates: Partial<Job>) => { const jobs = [...(db.jobs || [])]; const idx = jobs.findIndex((j: Job) => j.id === jobId); if (idx >= 0) { jobs[idx] = { ...jobs[idx], ...updates }; await saveData({ ...db, jobs }); } }, [db, saveData]);
  const createJobInDb = useCallback(async (data: Partial<Job>) => { const jobs = [...(db.jobs || [])]; const maxId = jobs.reduce((m: number, j: Job) => Math.max(m, j.id || 0), 0); jobs.push({ id: maxId + 1, num: formatJobNumber(maxId + 1), client: data.client || '', phone: data.phone || '', address: data.address || '', desc: data.desc || '', status: (data.status || 'open') as JobStatus, priority: data.priority || 'normal', tech: data.tech || '', techId: data.techId, scheduledDate: data.scheduledDate || '', scheduledTime: data.scheduledTime || '', created: new Date().toISOString(), notes: data.notes || '', source: 'schedule' } as Job); await saveData({ ...db, jobs }); }, [db, saveData]);
  const deleteJobFromDb = useCallback(async (jobId: number) => { await saveData({ ...db, jobs: (db.jobs || []).filter((j: Job) => j.id !== jobId) }); }, [db, saveData]);
  const handleDrop = async (date: string, time: string, techName?: string) => { if (!dragJob) return; const tech = techName ? technicians.find((t: User) => t.name === techName) : undefined; await updateJobInDb(dragJob.id, { scheduledDate: date, scheduledTime: time, tech: techName || dragJob.tech, techId: tech ? tech.id as number : dragJob.techId, status: techName ? 'assigned' as JobStatus : dragJob.status }); toast('עבודה הוזזה בהצלחה'); setDragJob(null); };
  const handleAutoAssign = async () => { const assignments = autoAssign(unassignedJobs, technicians, allJobs); if (!assignments.length) { toast('אין עבודות לשיבוץ'); return; } const jobs = [...(db.jobs || [])]; for (const a of assignments) { const idx = jobs.findIndex((j: Job) => j.id === a.jobId); if (idx >= 0) jobs[idx] = { ...jobs[idx], tech: a.techName, techId: a.techId as number, status: 'assigned' as JobStatus }; } await saveData({ ...db, jobs }); toast(`${assignments.length} עבודות שובצו`); };
  const handlePrint = (techName: string) => { const date = fmtDate(currentDate); const techJobs = allJobs.filter((j: Job) => j.tech === techName && getJobDate(j) === date).sort((a: Job, b: Job) => getJobTime(a).localeCompare(getJobTime(b))); const rows = techJobs.map((j: Job) => `<tr><td style="padding:8px;border:1px solid #ddd">${getJobTime(j)}</td><td style="padding:8px;border:1px solid #ddd">${j.desc || j.num}</td><td style="padding:8px;border:1px solid #ddd">${j.client}</td><td style="padding:8px;border:1px solid #ddd">${j.address || ''}</td></tr>`).join(''); const w = window.open('', '_blank'); if (w) { w.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Arial;padding:20px}table{width:100%;border-collapse:collapse}th{background:#1a1a2e;color:#fff;padding:10px;text-align:right}</style></head><body><h1>לוח עבודה — ${techName}</h1><h2>${date}</h2><table><tr><th>שעה</th><th>עבודה</th><th>לקוח</th><th>כתובת</th></tr>${rows}</table></body></html>`); w.document.close(); w.print(); } };
  const getCapacity = (techName: string, date: string) => { const n = allJobs.filter((j: Job) => j.tech === techName && getJobDate(j) === date && j.status !== 'cancelled').length; const pct = Math.min(100, Math.round((n * 60) / 480 * 100)); return { pct }; };
  const headerTitle = useMemo(() => { if (viewMode === 'day') { const d = new Date(fmtDate(currentDate) + 'T00:00:00'); return `${DAY_NAMES[d.getDay()]} ${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`; } if (viewMode === 'week' || viewMode === 'timeline') { const s = new Date(dateRange[0] + 'T00:00:00'); const e = new Date((dateRange[6] || dateRange[dateRange.length-1]) + 'T00:00:00'); return `${s.getDate()}/${s.getMonth()+1} — ${e.getDate()}/${e.getMonth()+1}/${e.getFullYear()}`; } return currentDate.toLocaleDateString('he-IL', { month: 'long', year: 'numeric' }); }, [viewMode, currentDate, dateRange]);

  return (
    <Box sx={{ display: 'flex', height: 'calc(100vh - 64px)', overflow: 'hidden', direction: 'rtl' }}>
      <Drawer variant={isMobile ? 'temporary' : 'persistent'} open={sidebarOpen} onClose={() => setSidebarOpen(false)} anchor="right" sx={{ width: sidebarOpen ? SIDEBAR_WIDTH : 0, flexShrink: 0, '& .MuiDrawer-paper': { width: SIDEBAR_WIDTH, position: 'relative', borderLeft: '1px solid rgba(255,255,255,0.08)', bgcolor: 'background.paper' } }}>
        <Box sx={{ p: 2 }}>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}><ScheduleIcon fontSize="small" />ממתינים לשיבוץ<Chip label={unassignedJobs.length} size="small" color="warning" sx={{ ml: 'auto' }} /></Typography>
          <Button fullWidth variant="contained" size="small" startIcon={<AutoFixHigh />} onClick={handleAutoAssign} sx={{ mb: 2, bgcolor: '#8B5CF6', '&:hover': { bgcolor: '#7C3AED' } }}>שיבוץ אוטומטי (AI)</Button>
          <Divider sx={{ mb: 1 }} />
          {unassignedJobs.length === 0 && <Typography variant="body2" color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>אין עבודות ממתינות</Typography>}
          {unassignedJobs.map((job: Job) => (
            <Paper key={job.id} draggable onDragStart={() => setDragJob(job)} sx={{ p: 1.5, mb: 1, cursor: 'grab', border: '1px solid rgba(255,255,255,0.1)', borderRight: `4px solid ${PRIORITY_CONFIG[job.priority || 'normal']?.color}`, borderRadius: 1.5, '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' } }}>
              <Typography variant="body2" fontWeight={600} noWrap>{job.num} — {job.client}</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><AccessTime sx={{ fontSize: 12 }} />{getJobDate(job) || 'ללא תאריך'} · {getJobTime(job)}</Typography>
              {job.address && <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><LocationOn sx={{ fontSize: 12 }} />{job.address}</Typography>}
            </Paper>
          ))}
        </Box>
      </Drawer>
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Box sx={{ px: 2, py: 1.5, display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap', borderBottom: '1px solid rgba(255,255,255,0.08)', bgcolor: 'background.paper' }}>
          <IconButton onClick={() => setSidebarOpen(!sidebarOpen)} size="small"><Badge badgeContent={unassignedJobs.length} color="warning"><ScheduleIcon /></Badge></IconButton>
          <IconButton onClick={() => navigate(-1)} size="small"><ChevronRight /></IconButton>
          <Button variant="outlined" size="small" onClick={() => setCurrentDate(new Date())} startIcon={<Today />}>היום</Button>
          <IconButton onClick={() => navigate(1)} size="small"><ChevronLeft /></IconButton>
          <Typography variant="h6" fontWeight={700} sx={{ minWidth: 180 }}>{headerTitle}</Typography>
          <Box sx={{ flex: 1 }} />
          <ToggleButtonGroup value={viewMode} exclusive onChange={(_, v) => v && setViewMode(v)} size="small">
            <ToggleButton value="day"><Tooltip title="יום"><ViewDay fontSize="small" /></Tooltip></ToggleButton>
            <ToggleButton value="week"><Tooltip title="שבוע"><ViewWeek fontSize="small" /></Tooltip></ToggleButton>
            <ToggleButton value="month"><Tooltip title="חודש"><CalendarMonth fontSize="small" /></Tooltip></ToggleButton>
            <ToggleButton value="timeline"><Tooltip title="ציר זמן"><ViewTimeline fontSize="small" /></Tooltip></ToggleButton>
          </ToggleButtonGroup>
          <IconButton size="small" onClick={(e) => setFilterAnchor(e.currentTarget)}><Badge badgeContent={selectedTechs.length < technicians.length ? selectedTechs.length : 0} color="primary"><FilterList /></Badge></IconButton>
          <Menu anchorEl={filterAnchor} open={Boolean(filterAnchor)} onClose={() => setFilterAnchor(null)}>
            <MenuItem onClick={() => setSelectedTechs(technicians.map((t: User) => t.name))}><Typography variant="body2" fontWeight={600}>הצג הכל</Typography></MenuItem>
            <Divider />
            {technicians.map((tech: User, ti: number) => (<MenuItem key={String(tech.id)} onClick={() => setSelectedTechs(prev => prev.includes(tech.name) ? prev.filter(n => n !== tech.name) : [...prev, tech.name])}><Checkbox checked={selectedTechs.includes(tech.name)} size="small" /><Avatar sx={{ width: 24, height: 24, bgcolor: getTechColor(ti), fontSize: 12, mr: 1 }}>{tech.name[0]}</Avatar><Typography variant="body2">{tech.name}</Typography></MenuItem>))}
          </Menu>
          <Button variant="contained" size="small" startIcon={<Add />} onClick={() => { setCreateSlot({ date: fmtDate(currentDate), time: '09:00' }); setCreateOpen(true); }} sx={{ bgcolor: '#10B981', '&:hover': { bgcolor: '#059669' } }}>עבודה חדשה</Button>
        </Box>
        {conflicts.length > 0 && <Alert severity="warning" sx={{ mx: 2, mt: 1, borderRadius: 2 }}><strong>⚠ {conflicts.length} התנגשויות!</strong>{conflicts.slice(0, 3).map((c: any, i: number) => <Typography key={i} variant="caption" display="block">{c.a.num || c.a.client} ↔ {c.b.num || c.b.client}</Typography>)}</Alert>}
        <Box ref={scrollRef} sx={{ flex: 1, overflow: 'auto', p: isMobile ? 1 : 2 }}>
          {viewMode === 'day' && <DayView date={fmtDate(currentDate)} jobs={filteredJobs} allJobs={allJobs} technicians={technicians.filter((t: User) => selectedTechs.includes(t.name))} onEdit={(j: Job) => { setEditJob(j); setEditOpen(true); }} onCreate={(d: string, t: string, tn?: string) => { setCreateSlot({ date: d, time: t, tech: tn }); setCreateOpen(true); }} onDragStart={setDragJob} onDrop={handleDrop} onPrint={handlePrint} getCapacity={getCapacity} />}
          {viewMode === 'week' && <WeekView dates={dateRange} jobs={filteredJobs} technicians={technicians} onEdit={(j: Job) => { setEditJob(j); setEditOpen(true); }} onCreate={(d: string, t: string) => { setCreateSlot({ date: d, time: t }); setCreateOpen(true); }} onDragStart={setDragJob} onDrop={handleDrop} />}
          {viewMode === 'month' && <MonthView dates={dateRange} currentMonth={currentDate.getMonth()} jobs={filteredJobs} technicians={technicians} onEdit={(j: Job) => { setEditJob(j); setEditOpen(true); }} onDayClick={(d: string) => { setCurrentDate(new Date(d + 'T00:00:00')); setViewMode('day'); }} />}
          {viewMode === 'timeline' && <TimelineView dates={dateRange} jobs={filteredJobs} allJobs={allJobs} technicians={technicians.filter((t: User) => selectedTechs.includes(t.name))} onEdit={(j: Job) => { setEditJob(j); setEditOpen(true); }} onDragStart={setDragJob} onDrop={handleDrop} getCapacity={getCapacity} />}
        </Box>
      </Box>
      <EditJobModal open={editOpen} job={editJob} technicians={technicians} onClose={() => { setEditOpen(false); setEditJob(null); }} onSave={async (data: Partial<Job>) => { if (editJob) { await updateJobInDb(editJob.id, data); toast('עבודה עודכנה'); } setEditOpen(false); setEditJob(null); }} onDelete={async () => { if (editJob) { await deleteJobFromDb(editJob.id); toast('עבודה נמחקה'); } setEditOpen(false); setEditJob(null); }} />
      <CreateJobModal open={createOpen} slot={createSlot} technicians={technicians} onClose={() => { setCreateOpen(false); setCreateSlot(null); }} onSave={async (data: Partial<Job>) => { await createJobInDb(data); toast('עבודה נוצרה'); setCreateOpen(false); setCreateSlot(null); }} />
    </Box>
  );
}

function DayView({ date, jobs, allJobs, technicians, onEdit, onCreate, onDragStart, onDrop, onPrint, getCapacity }: any) {
  const dayJobs = jobs.filter((j: Job) => getJobDate(j) === date);
  return (
    <Box sx={{ display: 'flex', gap: 0 }}>
      <Box sx={{ width: 60, flexShrink: 0, pt: '48px' }}>{HOURS.map(h => (<Box key={h} sx={{ height: HOUR_HEIGHT, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}><Typography variant="caption" color="text.secondary" sx={{ mt: '-8px' }}>{String(h).padStart(2, '0')}:00</Typography></Box>))}</Box>
      {technicians.map((tech: User, ti: number) => {
        const techJobs = dayJobs.filter((j: Job) => j.tech === tech.name);
        const cap = getCapacity(tech.name, date);
        const color = getTechColor(ti);
        return (
          <Box key={String(tech.id)} sx={{ flex: 1, minWidth: 180, borderRight: '1px solid rgba(255,255,255,0.06)' }}>
            <Box sx={{ height: 48, px: 1, display: 'flex', alignItems: 'center', gap: 1, borderBottom: '1px solid rgba(255,255,255,0.08)', bgcolor: 'rgba(255,255,255,0.02)', position: 'sticky', top: 0, zIndex: 2 }}>
              <Avatar sx={{ width: 28, height: 28, bgcolor: color, fontSize: 12 }}>{tech.name[0]}</Avatar>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography variant="body2" fontWeight={600} noWrap>{tech.name}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <LinearProgress variant="determinate" value={cap.pct} sx={{ flex: 1, height: 4, borderRadius: 2, bgcolor: 'rgba(255,255,255,0.08)', '& .MuiLinearProgress-bar': { bgcolor: cap.pct > 90 ? '#EF4444' : cap.pct > 70 ? '#F59E0B' : '#10B981' } }} />
                  <Typography variant="caption" color="text.secondary" sx={{ fontSize: 10 }}>{cap.pct}%</Typography>
                </Box>
              </Box>
              <Tooltip title="הדפס"><IconButton size="small" onClick={() => onPrint(tech.name)}><Print sx={{ fontSize: 16 }} /></IconButton></Tooltip>
            </Box>
            <Box sx={{ position: 'relative', height: HOURS.length * HOUR_HEIGHT }} onDragOver={(e: any) => e.preventDefault()} onDrop={(e: any) => { const rect = e.currentTarget.getBoundingClientRect(); onDrop(date, yToTime(e.clientY - rect.top), tech.name); }} onClick={(e: any) => { const rect = e.currentTarget.getBoundingClientRect(); onCreate(date, yToTime(e.clientY - rect.top), tech.name); }}>
              {HOURS.map(h => (<Box key={h} sx={{ position: 'absolute', top: (h - 6) * HOUR_HEIGHT, left: 0, right: 0, height: 1, bgcolor: 'rgba(255,255,255,0.05)' }} />))}
              {isTodayStr(date) && <Box sx={{ position: 'absolute', top: timeToY(`${new Date().getHours()}:${new Date().getMinutes()}`), left: 0, right: 0, height: 2, bgcolor: '#EF4444', zIndex: 3, '&::before': { content: '""', position: 'absolute', right: -4, top: -4, width: 10, height: 10, borderRadius: '50%', bgcolor: '#EF4444' } }} />}
              {techJobs.map((job: Job) => { const top = timeToY(getJobTime(job)); const height = Math.max((getJobDuration() / 60) * HOUR_HEIGHT, MIN_SLOT_HEIGHT); return (
                <Box key={job.id} draggable onDragStart={(e: any) => { e.stopPropagation(); onDragStart(job); }} onClick={(e: any) => { e.stopPropagation(); onEdit(job); }} sx={{ position: 'absolute', top, left: 4, right: 4, height, minHeight: MIN_SLOT_HEIGHT, bgcolor: `${color}22`, border: `1px solid ${color}66`, borderRight: `4px solid ${color}`, borderRadius: 1.5, px: 1, py: 0.5, cursor: 'grab', overflow: 'hidden', zIndex: 1, '&:hover': { boxShadow: `0 0 12px ${color}44`, zIndex: 5 } }}>
                  <Typography variant="caption" fontWeight={700} noWrap sx={{ color, fontSize: 11 }}>{getJobTime(job)} — {addMins(getJobTime(job), getJobDuration())}</Typography>
                  <Typography variant="body2" fontWeight={600} noWrap sx={{ fontSize: 12 }}>{job.num} {job.client}</Typography>
                  {height > 40 && <Typography variant="caption" color="text.secondary" noWrap sx={{ fontSize: 10 }}>{job.desc || job.address}</Typography>}
                  <Box sx={{ position: 'absolute', top: 2, left: 4 }}><Typography sx={{ fontSize: 10, color: PRIORITY_CONFIG[job.priority || 'normal']?.color }}>{PRIORITY_CONFIG[job.priority || 'normal']?.icon}</Typography></Box>
                </Box>
              ); })}
            </Box>
          </Box>
        );
      })}
    </Box>
  );
}

function WeekView({ dates, jobs, technicians, onEdit, onCreate, onDragStart, onDrop }: any) {
  return (
    <Box sx={{ display: 'flex', gap: 0 }}>
      <Box sx={{ width: 50, flexShrink: 0, pt: '36px' }}>{HOURS.map(h => (<Box key={h} sx={{ height: HOUR_HEIGHT, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}><Typography variant="caption" color="text.secondary" sx={{ mt: '-8px', fontSize: 10 }}>{String(h).padStart(2, '0')}:00</Typography></Box>))}</Box>
      {dates.slice(0, 7).map((date: string) => { const d = new Date(date + 'T00:00:00'); const dayJobs = jobs.filter((j: Job) => getJobDate(j) === date); return (
        <Box key={date} sx={{ flex: 1, minWidth: 100, borderRight: '1px solid rgba(255,255,255,0.06)' }}>
          <Box sx={{ height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', borderBottom: '1px solid rgba(255,255,255,0.08)', bgcolor: isTodayStr(date) ? 'rgba(59,130,246,0.15)' : 'rgba(255,255,255,0.02)', position: 'sticky', top: 0, zIndex: 2 }}>
            <Typography variant="caption" fontWeight={isTodayStr(date) ? 700 : 400} sx={{ color: isTodayStr(date) ? '#3B82F6' : 'text.secondary', fontSize: 11 }}>{DAY_NAMES[d.getDay()]} {d.getDate()}</Typography>
          </Box>
          <Box sx={{ position: 'relative', height: HOURS.length * HOUR_HEIGHT }} onDragOver={(e: any) => e.preventDefault()} onDrop={(e: any) => { const rect = e.currentTarget.getBoundingClientRect(); onDrop(date, yToTime(e.clientY - rect.top)); }} onClick={(e: any) => { const rect = e.currentTarget.getBoundingClientRect(); onCreate(date, yToTime(e.clientY - rect.top)); }}>
            {HOURS.map(h => (<Box key={h} sx={{ position: 'absolute', top: (h - 6) * HOUR_HEIGHT, left: 0, right: 0, height: 1, bgcolor: 'rgba(255,255,255,0.04)' }} />))}
            {isTodayStr(date) && <Box sx={{ position: 'absolute', top: timeToY(`${new Date().getHours()}:${new Date().getMinutes()}`), left: 0, right: 0, height: 2, bgcolor: '#EF4444', zIndex: 3 }} />}
            {dayJobs.map((job: Job) => { const top = timeToY(getJobTime(job)); const height = Math.max((getJobDuration() / 60) * HOUR_HEIGHT, MIN_SLOT_HEIGHT); const ti = technicians.findIndex((t: User) => t.name === job.tech); const clr = ti >= 0 ? getTechColor(ti) : (STATUS_COLORS[job.status]?.color || '#3B82F6'); return (
              <Box key={job.id} draggable onDragStart={(e: any) => { e.stopPropagation(); onDragStart(job); }} onClick={(e: any) => { e.stopPropagation(); onEdit(job); }} sx={{ position: 'absolute', top, left: 2, right: 2, height, minHeight: MIN_SLOT_HEIGHT, bgcolor: `${clr}22`, border: `1px solid ${clr}55`, borderRight: `3px solid ${clr}`, borderRadius: 1, px: 0.5, py: 0.3, cursor: 'grab', overflow: 'hidden', zIndex: 1, '&:hover': { boxShadow: `0 0 8px ${clr}44`, zIndex: 5 } }}>
                <Typography variant="caption" fontWeight={600} noWrap sx={{ fontSize: 10, color: clr }}>{getJobTime(job)}</Typography>
                <Typography variant="caption" noWrap sx={{ fontSize: 10, display: 'block' }}>{job.client}</Typography>
              </Box>
            ); })}
          </Box>
        </Box>
      ); })}
    </Box>
  );
}

function MonthView({ dates, currentMonth, jobs, technicians, onEdit, onDayClick }: any) {
  const weeks: string[][] = []; for (let i = 0; i < dates.length; i += 7) weeks.push(dates.slice(i, i + 7));
  return (
    <Box>
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)' }}>{DAY_NAMES.map(d => (<Box key={d} sx={{ p: 1, textAlign: 'center', borderBottom: '1px solid rgba(255,255,255,0.08)' }}><Typography variant="caption" fontWeight={600} color="text.secondary">{d}</Typography></Box>))}</Box>
      {weeks.map((week, wi) => (<Box key={wi} sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)' }}>{week.map((date: string) => { const d = new Date(date + 'T00:00:00'); const isCur = d.getMonth() === currentMonth; const dayJobs = jobs.filter((j: Job) => getJobDate(j) === date); return (
        <Box key={date} onClick={() => onDayClick(date)} sx={{ minHeight: 100, p: 0.5, border: '1px solid rgba(255,255,255,0.04)', cursor: 'pointer', bgcolor: isTodayStr(date) ? 'rgba(59,130,246,0.08)' : isCur ? 'transparent' : 'rgba(0,0,0,0.2)', '&:hover': { bgcolor: 'rgba(255,255,255,0.03)' } }}>
          <Typography variant="body2" sx={{ fontWeight: isTodayStr(date) ? 700 : 400, color: isTodayStr(date) ? '#3B82F6' : isCur ? 'text.primary' : 'text.disabled', textAlign: 'center', mb: 0.5 }}>{d.getDate()}</Typography>
          {dayJobs.slice(0, 3).map((job: Job) => { const ti = technicians.findIndex((t: User) => t.name === job.tech); const clr = ti >= 0 ? getTechColor(ti) : '#3B82F6'; return (<Box key={job.id} onClick={(e: any) => { e.stopPropagation(); onEdit(job); }} sx={{ px: 0.5, py: 0.2, mb: 0.3, borderRadius: 0.5, bgcolor: `${clr}22`, borderRight: `3px solid ${clr}`, cursor: 'pointer' }}><Typography variant="caption" noWrap sx={{ fontSize: 9 }}>{getJobTime(job)} {job.client}</Typography></Box>); })}
          {dayJobs.length > 3 && <Typography variant="caption" color="text.secondary" sx={{ fontSize: 9, textAlign: 'center', display: 'block' }}>+{dayJobs.length - 3}</Typography>}
        </Box>
      ); })}</Box>))}
    </Box>
  );
}

function TimelineView({ dates, jobs, allJobs, technicians, onEdit, onDragStart, onDrop, getCapacity }: any) {
  const [tlDate, setTlDate] = useState(dates.find((d: string) => isTodayStr(d)) || dates[0]);
  const dayJobs = jobs.filter((j: Job) => getJobDate(j) === tlDate);
  return (
    <Box>
      <Box sx={{ display: 'flex', gap: 1, mb: 2, overflowX: 'auto', pb: 1 }}>{dates.slice(0, 7).map((date: string) => (<Chip key={date} label={`${DAY_NAMES[new Date(date + 'T00:00:00').getDay()]} ${new Date(date + 'T00:00:00').getDate()}`} onClick={() => setTlDate(date)} variant={tlDate === date ? 'filled' : 'outlined'} color={isTodayStr(date) ? 'primary' : 'default'} size="small" />))}</Box>
      <Box sx={{ overflowX: 'auto' }}><Box sx={{ minWidth: HOURS.length * 80 + 150 }}>
        <Box sx={{ display: 'flex' }}><Box sx={{ width: 150, flexShrink: 0 }} />{HOURS.map(h => (<Box key={h} sx={{ width: 80, textAlign: 'center' }}><Typography variant="caption" color="text.secondary">{String(h).padStart(2, '0')}:00</Typography></Box>))}</Box>
        {technicians.map((tech: User, ti: number) => { const techJobs = dayJobs.filter((j: Job) => j.tech === tech.name); const cap = getCapacity(tech.name, tlDate); const color = getTechColor(ti); return (
          <Box key={String(tech.id)} sx={{ display: 'flex', alignItems: 'center', height: 50, borderBottom: '1px solid rgba(255,255,255,0.06)' }} onDragOver={(e: any) => e.preventDefault()} onDrop={(e: any) => { const rect = e.currentTarget.getBoundingClientRect(); const x = e.clientX - rect.left - 150; const hour = Math.floor(x / 80) + 6; const mins = Math.round(((x % 80) / 80) * 60 / 15) * 15; onDrop(tlDate, `${String(hour).padStart(2, '0')}:${String(mins).padStart(2, '0')}`, tech.name); }}>
            <Box sx={{ width: 150, flexShrink: 0, display: 'flex', alignItems: 'center', gap: 1, px: 1 }}><Avatar sx={{ width: 24, height: 24, bgcolor: color, fontSize: 10 }}>{tech.name[0]}</Avatar><Box><Typography variant="caption" fontWeight={600} noWrap>{tech.name}</Typography><Typography variant="caption" color="text.secondary" sx={{ fontSize: 9, display: 'block' }}>{cap.pct}% תפוס</Typography></Box></Box>
            <Box sx={{ position: 'relative', flex: 1, height: '100%' }}>
              {HOURS.map(h => (<Box key={h} sx={{ position: 'absolute', left: (h - 6) * 80, top: 0, bottom: 0, width: 1, bgcolor: 'rgba(255,255,255,0.04)' }} />))}
              {techJobs.map((job: Job) => { const [hh, mm] = getJobTime(job).split(':').map(Number); const startMin = hh * 60 + mm - 360; const left = (startMin / 60) * 80; const width = (getJobDuration() / 60) * 80; return (
                <Tooltip key={job.id} title={`${job.client} (${getJobTime(job)})`}><Box draggable onDragStart={() => onDragStart(job)} onClick={() => onEdit(job)} sx={{ position: 'absolute', left, top: 6, height: 38, width: Math.max(width, 20), bgcolor: `${color}33`, border: `1px solid ${color}`, borderRadius: 1, px: 0.5, display: 'flex', alignItems: 'center', cursor: 'grab', overflow: 'hidden', '&:hover': { bgcolor: `${color}55` } }}><Typography variant="caption" noWrap sx={{ fontSize: 10, fontWeight: 600 }}>{job.client}</Typography></Box></Tooltip>
              ); })}
            </Box>
          </Box>
        ); })}
      </Box></Box>
    </Box>
  );
}

function EditJobModal({ open, job, technicians, onClose, onSave, onDelete }: any) {
  const [form, setForm] = useState<Partial<Job>>({});
  useEffect(() => { if (job) setForm({ ...job }); }, [job]);
  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));
  if (!job) return null;
  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3, direction: 'rtl' } }}>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><Edit fontSize="small" />עריכת עבודה<Box sx={{ flex: 1 }} /><Chip label={STATUS_COLORS[form.status || 'open']?.he} size="small" sx={{ bgcolor: STATUS_COLORS[form.status || 'open']?.bg, color: STATUS_COLORS[form.status || 'open']?.color }} /></DialogTitle>
      <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
        <TextField label="לקוח" value={form.client || ''} onChange={e => set('client', e.target.value)} fullWidth size="small" />
        <Box sx={{ display: 'flex', gap: 2 }}><TextField label="טלפון" value={form.phone || ''} onChange={e => set('phone', e.target.value)} fullWidth size="small" /><TextField label="אימייל" value={form.email || ''} onChange={e => set('email', e.target.value)} fullWidth size="small" /></Box>
        <TextField label="כתובת" value={form.address || ''} onChange={e => set('address', e.target.value)} fullWidth size="small" />
        <TextField label="תיאור" value={form.desc || ''} onChange={e => set('desc', e.target.value)} fullWidth multiline rows={2} size="small" />
        <Box sx={{ display: 'flex', gap: 2 }}><TextField label="תאריך" type="date" value={form.scheduledDate || ''} onChange={e => set('scheduledDate', e.target.value)} fullWidth size="small" InputLabelProps={{ shrink: true }} /><TextField label="שעה" type="time" value={form.scheduledTime || ''} onChange={e => set('scheduledTime', e.target.value)} fullWidth size="small" InputLabelProps={{ shrink: true }} /></Box>
        <FormControl fullWidth size="small"><InputLabel>טכנאי</InputLabel><Select value={form.tech || ''} label="טכנאי" onChange={e => { const n = e.target.value; const t = technicians.find((x: User) => x.name === n); set('tech', n); set('techId', t?.id); if (n) set('status', 'assigned'); }}><MenuItem value=""><em>לא שובץ</em></MenuItem>{technicians.map((t: User, i: number) => (<MenuItem key={String(t.id)} value={t.name}><Avatar sx={{ width: 20, height: 20, bgcolor: getTechColor(i), fontSize: 10, mr: 1 }}>{t.name[0]}</Avatar>{t.name}</MenuItem>))}</Select></FormControl>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl size="small" sx={{ flex: 1 }}><InputLabel>סטטוס</InputLabel><Select value={form.status || 'open'} label="סטטוס" onChange={e => set('status', e.target.value)}>{Object.entries(STATUS_COLORS).map(([k, v]) => (<MenuItem key={k} value={k}>{v.he}</MenuItem>))}</Select></FormControl>
          <FormControl size="small" sx={{ flex: 1 }}><InputLabel>עדיפות</InputLabel><Select value={form.priority || 'normal'} label="עדיפות" onChange={e => set('priority', e.target.value)}>{Object.entries(PRIORITY_CONFIG).map(([k, v]) => (<MenuItem key={k} value={k}>{v.icon} {v.he}</MenuItem>))}</Select></FormControl>
        </Box>
        <TextField label="הערות" value={form.notes || ''} onChange={e => set('notes', e.target.value)} fullWidth multiline rows={2} size="small" />
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}><Button color="error" startIcon={<Delete />} onClick={onDelete}>מחק</Button><Box sx={{ flex: 1 }} /><Button onClick={onClose}>ביטול</Button><Button variant="contained" onClick={() => onSave(form)} sx={{ bgcolor: '#10B981' }}>שמור</Button></DialogActions>
    </Dialog>
  );
}

function CreateJobModal({ open, slot, technicians, onClose, onSave }: any) {
  const [form, setForm] = useState<Partial<Job>>({});
  useEffect(() => { if (slot) setForm({ client: '', phone: '', address: '', desc: '', notes: '', scheduledDate: slot.date, scheduledTime: slot.time, tech: slot.tech || '', status: slot.tech ? 'assigned' as JobStatus : 'open' as JobStatus, priority: 'normal' }); }, [slot]);
  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));
  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3, direction: 'rtl' } }}>
      <DialogTitle><Add fontSize="small" sx={{ mr: 1 }} />עבודה חדשה</DialogTitle>
      <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
        <TextField label="לקוח" value={form.client || ''} onChange={e => set('client', e.target.value)} fullWidth size="small" autoFocus />
        <Box sx={{ display: 'flex', gap: 2 }}><TextField label="טלפון" value={form.phone || ''} onChange={e => set('phone', e.target.value)} fullWidth size="small" /><TextField label="כתובת" value={form.address || ''} onChange={e => set('address', e.target.value)} fullWidth size="small" /></Box>
        <TextField label="תיאור" value={form.desc || ''} onChange={e => set('desc', e.target.value)} fullWidth size="small" />
        <Box sx={{ display: 'flex', gap: 2 }}><TextField label="תאריך" type="date" value={form.scheduledDate || ''} onChange={e => set('scheduledDate', e.target.value)} fullWidth size="small" InputLabelProps={{ shrink: true }} /><TextField label="שעה" type="time" value={form.scheduledTime || ''} onChange={e => set('scheduledTime', e.target.value)} fullWidth size="small" InputLabelProps={{ shrink: true }} /></Box>
        <FormControl fullWidth size="small"><InputLabel>טכנאי</InputLabel><Select value={form.tech || ''} label="טכנאי" onChange={e => { const n = e.target.value; const t = technicians.find((x: User) => x.name === n); set('tech', n); set('techId', t?.id); if (n) set('status', 'assigned'); }}><MenuItem value=""><em>לא שובץ</em></MenuItem>{technicians.map((t: User, i: number) => (<MenuItem key={String(t.id)} value={t.name}><Avatar sx={{ width: 20, height: 20, bgcolor: getTechColor(i), fontSize: 10, mr: 1 }}>{t.name[0]}</Avatar>{t.name}</MenuItem>))}</Select></FormControl>
        <FormControl size="small"><InputLabel>עדיפות</InputLabel><Select value={form.priority || 'normal'} label="עדיפות" onChange={e => set('priority', e.target.value)}>{Object.entries(PRIORITY_CONFIG).map(([k, v]) => (<MenuItem key={k} value={k}>{v.icon} {v.he}</MenuItem>))}</Select></FormControl>
        <TextField label="הערות" value={form.notes || ''} onChange={e => set('notes', e.target.value)} fullWidth multiline rows={2} size="small" />
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}><Button onClick={onClose}>ביטול</Button><Button variant="contained" onClick={() => onSave(form)} sx={{ bgcolor: '#10B981' }}>צור עבודה</Button></DialogActions>
    </Dialog>
  );
}
