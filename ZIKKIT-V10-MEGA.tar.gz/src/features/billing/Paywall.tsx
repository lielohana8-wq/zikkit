'use client';
import { Box, Typography, Button } from '@mui/material';
import { zikkitColors as c } from '@/styles/theme';
import { useAuth } from '@/features/auth/AuthProvider';
import { useData } from '@/hooks/useFirestore';

function useTrialInfo() {
  const { cfg } = useData();
  const trialEnds = (cfg as Record<string, unknown>)?.trialEnds as string;
  const planStatus = (cfg as Record<string, unknown>)?.planStatus as string;
  if (!trialEnds) return { isTrialActive: false, isPaywalled: false, daysLeft: 0 };
  const end = new Date(trialEnds).getTime();
  const now = Date.now();
  const daysLeft = Math.max(0, Math.ceil((end - now) / (24 * 60 * 60 * 1000)));
  const isTrialActive = planStatus === 'trial' && daysLeft > 0;
  const isPaywalled = planStatus === 'trial' && daysLeft <= 0;
  return { isTrialActive, isPaywalled, daysLeft };
}

export function Paywall({ children }: { children: React.ReactNode }) {
  const { isPaywalled } = useTrialInfo();
  const { user } = useAuth();
  if (user?.role === 'super_admin') return <>{children}</>;
  if (!isPaywalled) return <>{children}</>;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '70vh', textAlign: 'center', px: 3 }}>
      <Box sx={{ fontSize: 56, mb: 2 }}>🔒</Box>
      <Typography sx={{ fontSize: 24, fontWeight: 900, fontFamily: 'Syne, sans-serif', mb: 1 }}>תקופת הניסיון הסתיימה</Typography>
      <Typography sx={{ fontSize: 14, color: c.text2, maxWidth: 440, lineHeight: 1.7, mb: 3 }}>
        תקופת הניסיון של 14 יום הסתיימה. הירשם לתוכנית בתשלום כדי להמשיך להשתמש ב-ZIKKIT.
      </Typography>
      <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', justifyContent: 'center' }}>
        <Button href="/checkout" sx={{ bgcolor: c.accent, color: '#000', fontWeight: 800, fontSize: 14, px: 4, py: 1.5, borderRadius: '12px', textTransform: 'none', '&:hover': { bgcolor: c.accent2 } }}>
          שדרג עכשיו
        </Button>
      </Box>
    </Box>
  );
}

export function TrialBanner() {
  const { isTrialActive, daysLeft } = useTrialInfo();
  const { user } = useAuth();
  if (!isTrialActive || user?.role === 'super_admin') return null;

  const urgent = daysLeft <= 3;
  return (
    <Box sx={{ px: 2, py: 1, bgcolor: urgent ? 'rgba(255,77,109,0.1)' : 'rgba(245,158,11,0.08)', borderBottom: `1px solid ${urgent ? 'rgba(255,77,109,0.2)' : 'rgba(245,158,11,0.15)'}`, textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1 }}>
      <Typography sx={{ fontSize: 12, fontWeight: 600, color: urgent ? c.hot : c.warm }}>
        {urgent ? `⚠️ נשארו ${daysLeft} ימים לניסיון — ` : `נשארו ${daysLeft} ימים בתקופת הניסיון — `}
        אחרי הניסיון, חיוב אוטומטי לפי התוכנית שבחרת
      </Typography>
      <Button href="/checkout" size="small" sx={{ fontSize: 11, fontWeight: 700, color: urgent ? c.hot : c.warm, textDecoration: 'underline', textTransform: 'none', p: 0, minWidth: 'auto' }}>
        צפה בתוכנית
      </Button>
    </Box>
  );
}
