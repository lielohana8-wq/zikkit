'use client';

import { Box, type SxProps, type Theme } from '@mui/material';

interface BadgeProps {
  label: string;
  variant?: string;
  sx?: SxProps<Theme>;
}

function getStyle(v: string): { bg: string; color: string } {
  switch (v) {
    case 'hot': return { bg: 'rgba(255,77,109,0.1)', color: '#ff4d6d' };
    case 'warm': return { bg: 'rgba(245,158,11,0.1)', color: '#f59e0b' };
    case 'open': return { bg: 'rgba(79,143,255,0.1)', color: '#4f8fff' };
    case 'blue': return { bg: 'rgba(79,143,255,0.1)', color: '#4f8fff' };
    case 'done': return { bg: 'rgba(34,197,94,0.1)', color: '#22c55e' };
    case 'green': return { bg: 'rgba(34,197,94,0.1)', color: '#22c55e' };
    case 'new': return { bg: 'rgba(0,229,176,0.08)', color: '#00e5b0' };
    case 'accent': return { bg: 'rgba(0,229,176,0.08)', color: '#00e5b0' };
    case 'purple': return { bg: 'rgba(167,139,250,0.1)', color: '#a78bfa' };
    case 'teal': return { bg: 'rgba(6,182,212,0.1)', color: '#06b6d4' };
    default: return { bg: 'rgba(255,255,255,0.05)', color: '#5a7080' };
  }
}

export function Badge({ label, variant, sx }: BadgeProps) {
  const s = getStyle(variant || 'grey');
  return (
    <Box
      component="span"
      sx={{
        display: 'inline-flex',
        alignItems: 'center',
        px: '10px',
        py: '3px',
        borderRadius: '20px',
        fontSize: '10px',
        fontWeight: 700,
        letterSpacing: '0.2px',
        bgcolor: s.bg,
        color: s.color,
        ...sx,
      }}
    >
      {label}
    </Box>
  );
}
