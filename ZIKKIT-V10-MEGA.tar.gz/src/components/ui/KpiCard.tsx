'use client';

import { Box, Typography } from '@mui/material';
import { zikkitColors as c } from '@/styles/theme';

type KpiVariant = 'accent' | 'blue' | 'green' | 'warm' | 'hot' | 'teal' | 'purple';

const GRADIENT_MAP: Record<KpiVariant, string> = {
  accent: `linear-gradient(90deg, ${c.accent}, ${c.teal})`,
  blue: `linear-gradient(90deg, ${c.blue}, ${c.purple})`,
  green: `linear-gradient(90deg, ${c.green}, ${c.teal})`,
  warm: `linear-gradient(90deg, ${c.warm}, #f97316)`,
  hot: `linear-gradient(90deg, ${c.hot}, ${c.purple})`,
  teal: `linear-gradient(90deg, ${c.teal}, ${c.blue})`,
  purple: `linear-gradient(90deg, ${c.purple}, ${c.blue})`,
};

interface KpiCardProps {
  label: string;
  value: string | number;
  subtitle?: string;
  variant?: KpiVariant;
}

export function KpiCard({ label, value, subtitle, variant = 'accent' }: KpiCardProps) {
  return (
    <Box
      sx={{
        bgcolor: c.surface2,
        border: `1px solid ${c.border}`,
        borderRadius: '14px',
        p: '16px',
        position: 'relative',
        overflow: 'hidden',
        transition: 'all 0.2s cubic-bezier(0.4,0,0.2,1)',
        cursor: 'default',
        '&:hover': {
          transform: 'translateY(-3px)',
          borderColor: c.border2,
          boxShadow: '0 14px 36px rgba(0,0,0,0.3)',
        },
        '&::after': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '2px',
          borderRadius: '14px 14px 0 0',
          background: GRADIENT_MAP[variant],
        },
      }}
    >
      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: c.text3,
          textTransform: 'uppercase',
          letterSpacing: '0.6px',
          mb: '8px',
        }}
      >
        {label}
      </Typography>
      <Typography
        sx={{
          fontFamily: "'Syne', sans-serif",
          fontSize: 26,
          fontWeight: 800,
          lineHeight: 1,
          letterSpacing: '-1px',
        }}
      >
        {value}
      </Typography>
      {subtitle && (
        <Typography sx={{ fontSize: 10, color: c.text3, mt: '5px' }}>
          {subtitle}
        </Typography>
      )}
    </Box>
  );
}
