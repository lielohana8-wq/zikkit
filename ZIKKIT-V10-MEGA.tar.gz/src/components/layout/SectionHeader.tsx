'use client';

import { Box, Typography, type SxProps, type Theme } from '@mui/material';
import { zikkitColors as c } from '@/styles/theme';
import type { ReactNode } from 'react';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  sx?: SxProps<Theme>;
}

export function SectionHeader({ title, subtitle, actions, sx }: SectionHeaderProps) {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        p: '18px 20px 12px',
        ...sx,
      }}
    >
      <Box>
        <Typography
          sx={{
            fontFamily: "'Syne', sans-serif",
            fontSize: 20,
            fontWeight: 800,
            color: c.text,
            letterSpacing: '-0.5px',
          }}
        >
          {title}
        </Typography>
        {subtitle && (
          <Typography sx={{ fontSize: 12, color: c.text3, mt: '3px' }}>
            {subtitle}
          </Typography>
        )}
      </Box>
      {actions && <Box sx={{ display: 'flex', gap: '8px', alignItems: 'center' }}>{actions}</Box>}
    </Box>
  );
}
