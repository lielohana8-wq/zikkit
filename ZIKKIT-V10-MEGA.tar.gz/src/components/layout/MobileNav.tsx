'use client';

import { Box } from '@mui/material';
import { useRouter, usePathname } from 'next/navigation';
import { zikkitColors as c } from '@/styles/theme';
import { useAuth } from '@/features/auth/AuthProvider';
import { useRolePermissions } from '@/hooks/useRolePermissions';
import { useLanguage } from '@/hooks/useLanguage';

const OWNER_MOB = [
  { icon: '📊', label: 'Home', he: 'ראשי', href: '/dashboard' },
  { icon: '👥', label: 'Leads', he: 'לידים', href: '/leads' },
  { icon: '🔧', label: 'Jobs', he: 'עבודות', href: '/jobs' },
  { icon: '📄', label: 'Quotes', he: 'הצעות', href: '/quotes' },
  { icon: '⚙️', label: 'More', he: 'עוד', href: '/settings' },
];

const TECH_MOB = [
  { icon: '📊', label: 'Home', he: 'ראשי', href: '/tech/dashboard' },
  { icon: '🔧', label: 'Jobs', he: 'עבודות', href: '/tech/jobs' },
  { icon: '📄', label: 'Quotes', he: 'הצעות', href: '/tech/quotes' },
  { icon: '📅', label: 'לוח זמנים', he: 'יומן', href: '/tech/schedule' },
  { icon: '📍', label: 'GPS', he: 'מיקום', href: '/tech/gps' },
];

export function MobileNav() {
  const router = useRouter();
  const pathname = usePathname();
  const { user } = useAuth();
  const { lang } = useLanguage();
  const perms = useRolePermissions(user?.role, user?.customPermissions);

  const items = perms.isTechnician ? TECH_MOB : OWNER_MOB;

  return (
    <Box
      sx={{
        display: 'none',
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        bgcolor: c.surface1,
        borderTop: `1px solid ${c.border}`,
        zIndex: 100,
        justifyContent: 'space-around',
        alignItems: 'center',
        backdropFilter: 'blur(20px)',
        // Safe area for iPhone notch/home indicator
        pb: 'env(safe-area-inset-bottom, 0px)',
        pt: '8px',
        minHeight: 60,
        '@media (max-width: 768px)': { display: 'flex !important' },
      }}
    >
      {items.map((item) => {
        const active = pathname === item.href || pathname?.startsWith(item.href + '/');
        return (
          <Box
            key={item.href}
            onClick={() => router.push(item.href)}
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              cursor: 'pointer',
              gap: '3px',
              color: active ? c.accent : c.text3,
              fontSize: 10,
              fontWeight: active ? 700 : 500,
              minWidth: 48,
              minHeight: 44,
              justifyContent: 'center',
              borderRadius: '8px',
              transition: '0.15s',
              position: 'relative',
              '&:active': { transform: 'scale(0.92)' },
            }}
          >
            <Box sx={{ fontSize: 22, lineHeight: 1 }}>{item.icon}</Box>
            <span>{lang === 'he' ? item.he : item.label}</span>
            {active && (
              <Box sx={{
                position: 'absolute', top: -1, left: '50%', transform: 'translateX(-50%)',
                width: 20, height: 3, borderRadius: 2, bgcolor: c.accent,
              }} />
            )}
          </Box>
        );
      })}
    </Box>
  );
}
