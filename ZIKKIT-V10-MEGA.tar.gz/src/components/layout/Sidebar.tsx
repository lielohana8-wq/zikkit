'use client';

import { useState, type ReactNode } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Box, Tooltip, Typography } from '@mui/material';
import { zikkitColors as c } from '@/styles/theme';
import { useAuth } from '@/features/auth/AuthProvider';
import { useLanguage } from '@/hooks/useLanguage';
import { useRolePermissions } from '@/hooks/useRolePermissions';

interface NavItem {
  key: string;
  icon: string;
  label: string;
  href: string;
  badge?: number;
}

const OWNER_NAV: NavItem[] = [
  { key: 'dashboard', icon: '📊', label: 'דשבורד', href: '/dashboard' },
  { key: 'leads', icon: '👥', label: 'לידים / CRM', href: '/leads' },
  { key: 'jobs', icon: '🔧', label: 'עבודות', href: '/jobs' },
  { key: 'schedule', icon: '📅', label: 'לוח זמנים', href: '/schedule' },
  { key: 'quotes', icon: '📄', label: 'הצעות מחיר', href: '/quotes' },
  { key: 'technicians', icon: '👷', label: 'טכנאים', href: '/technicians' },
  { key: 'inventory', icon: '📦', label: 'מלאי וחלקים', href: '/inventory' },
  { key: 'products', icon: '🏷️', label: 'מחירון', href: '/products' },
  { key: 'whatsapp', icon: '💬', label: 'וואטסאפ בוט', href: '/whatsapp' },
  { key: 'reviews', icon: '⭐', label: 'ביקורות', href: '/reviews' },
  { key: 'membership', icon: '🏆', label: 'מנויים', href: '/membership' },
  { key: 'financing', icon: '💳', label: 'תשלומים', href: '/financing' },
  { key: 'photos', icon: '📸', label: 'תמונות', href: '/photos' },
  { key: 'reports', icon: '📈', label: 'דוחות', href: '/reports' },
  { key: 'payroll', icon: '💰', label: 'שכר', href: '/payroll' },
  { key: 'users', icon: '🔐', label: 'משתמשים', href: '/users' },
  { key: 'aibot', icon: '🤖', label: 'בוט AI קולי', href: '/aibot' },
  { key: 'gps', icon: '🗺️', label: 'מעקב GPS', href: '/gps-tracking' },
  { key: 'settings', icon: '⚙️', label: 'הגדרות', href: '/settings' },
];

const TECH_NAV: NavItem[] = [
  { key: 'tech-dashboard', icon: '📊', label: 'הדשבורד שלי', href: '/tech/dashboard' },
  { key: 'tech-jobs', icon: '🔧', label: 'העבודות שלי', href: '/tech/jobs' },
  { key: 'tech-quotes', icon: '📄', label: 'ההצעות שלי', href: '/tech/quotes' },
  { key: 'tech-schedule', icon: '📅', label: 'לוח זמנים', href: '/tech/schedule' },
  { key: 'tech-gps', icon: '📍', label: 'המיקום שלי', href: '/tech/gps' },
];



const LABELS_HE: Record<string, string> = {
  'Dashboard': 'דשבורד', 'Leads / CRM': 'לידים / CRM', 'Jobs': 'עבודות',
  'Quotes': 'הצעות מחיר', 'Technicians': 'טכנאים', 'Price List': 'מחירון',
  'Reports': 'דוחות', 'Payroll': 'שכר', 'User Management': 'ניהול משתמשים',
  'Settings': 'הגדרות', 'My Dashboard': 'הדשבורד שלי', 'My Jobs': 'העבודות שלי',
  'My Quotes': 'ההצעות שלי', "Today's Schedule": 'לוח זמנים', 'My Location': 'המיקום שלי',
  'Business': 'עסק', 'Technician': 'טכנאי',
};

export function Sidebar() {
  const [hovered, setHovered] = useState(false);
  const router = useRouter();
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const { lang } = useLanguage();
  const perms = useRolePermissions(user?.role, user?.customPermissions);
  const isHe = lang === 'he';
  const L = (en: string) => (isHe && LABELS_HE[en]) ? LABELS_HE[en] : en;

  const isSA = user?.role === 'super_admin';
  
  const isTechPath = pathname.startsWith('/tech/') || pathname === '/tech';

  const navItems = (isTechPath || perms.isTechnician)
      ? TECH_NAV
      : OWNER_NAV;

  const initials = (user?.name || 'U')
    .split(' ')
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <Box
      component="nav"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      sx={{
        width: hovered ? 218 : 56,
        minWidth: hovered ? 218 : 56,
        height: '100vh',
        bgcolor: c.surface1,
        borderRight: `1px solid ${c.border}`,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        overflow: 'hidden',
        flexShrink: 0,
        transition: 'width 0.28s cubic-bezier(0.4,0,0.2,1), min-width 0.28s cubic-bezier(0.4,0,0.2,1)',
        zIndex: 30,
        '@media (max-width: 600px)': { display: 'none !important' },
      }}
    >
      {/* Logo area */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 0,
          p: '16px 11px 14px',
          width: '100%',
          borderBottom: `1px solid ${c.border}`,
          flexShrink: 0,
        }}
      >
        <Box
          sx={{
            width: hovered ? 38 : 34,
            height: hovered ? 38 : 34,
            minWidth: hovered ? 38 : 34,
            background: hovered ? 'transparent' : `linear-gradient(135deg, ${c.accent}, ${c.accent2})`,
            borderRadius: hovered ? '8px' : '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
            overflow: 'hidden',
            position: 'relative',
            boxShadow: hovered ? 'none' : `0 0 0 1px rgba(0,229,176,0.3), 0 4px 14px ${c.accentGlow}`,
            transition: 'all 0.28s cubic-bezier(0.4,0,0.2,1)',
          }}
        >
          <Typography
            sx={{
              fontFamily: "'Syne', sans-serif",
              fontWeight: 900,
              fontSize: 16,
              color: '#000',
              opacity: hovered ? 0 : 1,
              transition: 'opacity 0.15s',
              position: 'absolute',
            }}
          >
            Z
          </Typography>
        </Box>
        {/* Business name when expanded */}
        <Box
          sx={{
            ml: '10px',
            opacity: hovered ? 1 : 0,
            transition: 'opacity 0.2s 0.05s',
            overflow: 'hidden',
            minWidth: 0,
          }}
        >
          <Typography
            sx={{
              fontFamily: "'Syne', sans-serif",
              fontWeight: 800,
              fontSize: 13,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              letterSpacing: '-0.3px',
              lineHeight: 1.2,
            }}
          >
            Zikkit
          </Typography>
          <Typography
            sx={{
              fontSize: 9,
              color: c.text3,
              letterSpacing: '0.5px',
            }}
          >
            {(isTechPath || perms.isTechnician) ? L('Technician') : L('Business')}
          </Typography>
        </Box>
      </Box>

      {/* Separator */}
      <Box sx={{ width: '100%', height: '1px', bgcolor: c.border, my: '6px', flexShrink: 0 }} />

      {/* Navigation items */}
      <Box sx={{ overflow: 'auto', flex: 1, width: '100%' }}>
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Tooltip
              key={item.key}
              title={hovered ? '' : L(item.label)}
              placement="right"
              arrow
            >
              <Box
                onClick={() => router.push(item.href)}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '11px',
                  width: '100%',
                  p: '9px 11px 9px 17px',
                  cursor: 'pointer',
                  color: isActive ? c.accent : c.text3,
                  fontSize: 12,
                  fontWeight: isActive ? 600 : 500,
                  borderLeft: `2px solid ${isActive ? c.accent : 'transparent'}`,
                  background: isActive ? c.accentDim : 'transparent',
                  transition: 'all 0.15s',
                  whiteSpace: 'nowrap',
                  position: 'relative',
                  '&:hover': {
                    color: c.text2,
                    background: c.glass2,
                  },
                }}
              >
                <Box
                  sx={{
                    fontSize: 15,
                    minWidth: 20,
                    textAlign: 'center',
                    flexShrink: 0,
                    transform: isActive ? 'scale(1.1)' : 'none',
                    transition: 'transform 0.15s',
                  }}
                >
                  {item.icon}
                </Box>
                <Box
                  component="span"
                  sx={{
                    opacity: hovered ? 1 : 0,
                    transform: hovered ? 'none' : 'translateX(8px)',
                    transition: 'opacity 0.2s, transform 0.2s',
                    overflow: 'hidden',
                    maxWidth: hovered ? 140 : 0,
                    fontSize: 12,
                    flex: 1,
                  }}
                >
                  {L(item.label)}
                </Box>
                {item.badge != null && item.badge > 0 && (
                  <Box
                    sx={{
                      ml: 'auto',
                      bgcolor: c.hot,
                      color: '#fff',
                      borderRadius: '6px',
                      p: '2px 6px',
                      fontSize: 9,
                      fontWeight: 800,
                      flexShrink: 0,
                      animation: 'pulse 2.5s ease-in-out infinite',
                      ...(hovered
                        ? { position: 'static' }
                        : { position: 'absolute', top: 4, right: 6 }),
                    }}
                  >
                    {item.badge}
                  </Box>
                )}
              </Box>
            </Tooltip>
          );
        })}
      </Box>

      {/* User footer */}
      <Box
        sx={{
          flexShrink: 0,
          width: '100%',
          p: '10px',
          borderTop: `1px solid ${c.border}`,
        }}
      >
        <Box
          onClick={logout}
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: '9px',
            cursor: 'pointer',
            p: '6px',
            borderRadius: '10px',
            width: '100%',
            transition: 'background 0.15s',
            '&:hover': { background: c.glass2 },
          }}
        >
          <Box
            sx={{
              width: 30,
              height: 30,
              minWidth: 30,
              borderRadius: '50%',
              background: perms.isTechnician
                ? `linear-gradient(135deg, ${c.blue}, #3470dd)`
                : `linear-gradient(135deg, ${c.accent}, ${c.accent2})`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 11,
              fontWeight: 800,
              color: '#000',
              flexShrink: 0,
              boxShadow: perms.isTechnician
                ? '0 0 0 2px rgba(79,143,255,0.3)'
                : `0 0 0 2px ${c.accentMid}`,
            }}
          >
            {initials}
          </Box>
          <Box
            component="span"
            sx={{
              opacity: hovered ? 1 : 0,
              transition: 'opacity 0.2s',
              fontSize: 11,
              fontWeight: 600,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              maxWidth: hovered ? 140 : 0,
              color: c.text2,
            }}
          >
            {user?.name || 'User'}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
